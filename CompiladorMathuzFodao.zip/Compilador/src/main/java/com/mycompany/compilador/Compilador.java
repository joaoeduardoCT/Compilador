/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.compilador;

/**
 *
 * @author joaoe
 */
public class Compilador {

    public static void main(String[] args) {
         // Caminho relativo à raiz do classpath
        String addPath = "/com/mycompany/imgs/add-file(2).png";
        String editPath = "/com/mycompany/imgs/edit.png";
        String filePath = "/com/mycompany/imgs/file.png";
        String folderOnePath = "/com/mycompany/imgs/folder(1).png";
        String playPath = "/com/mycompany/imgs/play.png";
        String customersPath = "/com/mycompany/imgs/customers.png";
        String folderPath = "/com/mycompany/imgs/folder.png";
    }
}